from django.apps import AppConfig


class GraphdescripConfig(AppConfig):
    name = 'GraphDescrip'
