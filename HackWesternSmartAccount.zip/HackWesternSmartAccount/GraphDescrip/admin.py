from django.contrib import admin

from .models import GraphDescrip

admin.site.register(GraphDescrip)
