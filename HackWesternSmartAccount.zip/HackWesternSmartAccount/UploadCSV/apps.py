from django.apps import AppConfig


class UploadcsvConfig(AppConfig):
    name = 'UploadCSV'
