from django.apps import AppConfig


class AccountrecommendationlistConfig(AppConfig):
    name = 'AccountRecommendationList'
